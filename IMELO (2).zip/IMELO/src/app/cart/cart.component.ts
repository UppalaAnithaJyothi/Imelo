import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';
declare var jQuery:any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems:any;
  editObject:any;
  customer:any;
  restaurant:any;
  orderType:any;
  amount:any;
  atime:any;
  constructor(private service :RestaurantService,private router:Router) {
   
    this.amount=this.service.amount;
    this.editObject={};
    console.log('NgOn Init : ',this.amount);
   }

  ngOnInit(): void {
    this.customer =  JSON.parse(sessionStorage.getItem('customer'));
    this.restaurant = JSON.parse(sessionStorage.getItem('restaurant'));
    this.orderType = JSON.parse(sessionStorage.getItem('orderType'));
    this.cartItems=this.service.displayCartItems;
  }
  check(){
    //console.log(this.amount)
    if(this.amount === 0){
      return true;
    }
    else{
      return false;
    }
  }
  goToRest(){this.router.navigate(['customerHome'])}
  
  purchase(){
  console.log("sent");
  if(this.orderType==="Takeaway"){ 
   this.confirm();

   // this.service.confirmOrders(this.cartItems,this.restaurant,this.customer,this.orderType,this.amount,this.atime).subscribe();
  }
  else if(this.orderType==="Table Reservation"){
    this.router.navigate(['payment']);
  }

  //this.service.confirmOrders(this.cartItems,this.restaurant,this.customer,this.orderType,this.amount,this.atime).subscribe();

}
confirm(){
    //alert("method called");
    jQuery('#arrivalModel').modal('show');

}
ok(){
  sessionStorage.setItem("arrivalTime",this.atime);
  this.router.navigate(['payment']);
}
delete(item:any){
  this.service.delete(item);
  this.amount=this.service.amount;
  console.log("delete cartItem", this.service.cartItems);
  console.log("delete display cartItem", this.service.displayCartItems);

}
edit(item:any){
    this.editObject=item;
    jQuery('#quantityModel').modal('show');
    this.amount=this.service.amount;
}
update(){
  console.log("cart edit object", this.editObject);
  console.log("before edit", this.service.displayCartItems)
  this.service.update(this.editObject);
  this.amount=this.service.amount;
  
  console.log("edit cartItem", this.service.cartItems);
  console.log("edit display cartItem", this.service.displayCartItems);
}



}
