import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'datefilter'
})
export class DatefilterPipe implements PipeTransform {
  currentTime: any
  a:any;
  b:any;
  transform(value: any, date: any, availability:any): any {
    this.currentTime = new Date().getTime()
   
    this.a = value.split(':');
    this.b = date.split('-')
    var x = this.b[0] + ',' + this.b[1] + ',' + this.b[2] + ' ' + this.a[0] + ':' + this.a[1];
    var finaldate = new Date(x);
    if(finaldate > new Date() && availability != 0){
      return value;
    }
    else{
      return '';
    }
  }
  

}