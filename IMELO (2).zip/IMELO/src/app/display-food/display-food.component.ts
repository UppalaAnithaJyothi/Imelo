import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
declare var jQuery: any;
@Component({
  selector: 'app-display-food',
  templateUrl: './display-food.component.html',
  styleUrls: ['./display-food.component.css']
})
export class DisplayFoodComponent implements OnInit {
restaurant:any;
foodList:any;
orderType:any;
bookDetails:any;
editDetails:any;
tableList:any;
cartItem:any;
cartItems: any;
searchText:any;
  constructor(private service:RestaurantService) {
    this.editDetails={date:'',time:'',guests:'',adds:''};
    this.cartItem=[];
    this.cartItems=this.service.cartItems;
  }

  ngOnInit(): void {
    this.restaurant =  JSON.parse(sessionStorage.getItem('restaurant'));
    this.orderType = JSON.parse(sessionStorage.getItem('orderType'));
    this.bookDetails = JSON.parse(sessionStorage.getItem('bookDetails'));
    this.foodList= this.restaurant.foodList;
    this.tableList = this.restaurant.tableList;
  }

  bookTable(){
    if(this.orderType==='Table Reservation'){
      this.bookDetails = JSON.parse(sessionStorage.getItem('bookDetails'));
      return true;

    }
  }
  takeaway(){
    return(this.orderType==='Takeaway');
  }
  delivery(){
    return(this.orderType==='Delivery');
  }
  showEditPopup(bookDetail: any) {
    this.editDetails = bookDetail;
    jQuery('#edit').modal('show');
  }
  updateBooking(){
    this.bookDetails = this.editDetails;
    sessionStorage.setItem('bookDetails', JSON.stringify(this.bookDetails));

  }
  showPopup(food:any){
    this.cartItem.food = food;
    this.cartItem.price = food.price;
    this.cartItem.quantity = 0;

    jQuery('#quantityModel').modal('show');
  }
  addToCart(){
    this.cartItem.totalPrice = Number(this.cartItem.quantity) * Number(this.cartItem.price);
    this.service.addToCart(this.cartItem);
    console.log('Inside addto cart ', this.cartItem);
  }







}
