import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import {formatDate} from '@angular/common';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
bookDetails:any;
mail:any;
restaurant:any;
arrivalTime:any;
customer:any;
amount:any;

  constructor(private service:RestaurantService,private router:Router,private toastr:ToastrService) {
this.mail={};
this.bookDetails={};
this.amount = this.service.amount;
   }

  ngOnInit(): void {
    this.arrivalTime = (sessionStorage.getItem('arrivalTime'));
    //alert(this.arrivalTime);


    this.restaurant = JSON.parse(sessionStorage.getItem('restaurant'));
    this.mail.orderType = JSON.parse(sessionStorage.getItem('orderType'));
    this.customer =  JSON.parse(sessionStorage.getItem('customer'));


  }
  check(){
    if(this.mail.orderType === 'Table Reservation'){
      this.bookDetails=JSON.parse(sessionStorage.getItem('bookDetails'));
      this.service.confirmOrders(this.restaurant,this.customer,this.mail.orderType,this.amount,this.bookDetails).subscribe();
    }
    else if(this.mail.orderType === 'Takeaway'){

      this.bookDetails.time=this.arrivalTime;
     this.bookDetails.date=formatDate(new Date(), 'yyyy-MM-dd', 'en');
      // console.log(typeof(this.bookDetails.date))
      // console.log(this.bookDetails.time);
      // console.log(this.bookDetails.date);

      this.service.confirmOrders(this.restaurant,this.customer,this.mail.orderType,this.amount,this.bookDetails).subscribe();

    }
    this.mail.restaurantEmail = this.restaurant.email;
    this.toastr.info('Payment Successful','Order Placed!! Please Check your mail')
    this.router.navigate(['customerHome']);
  console.log("insideTS",this.mail)
    //this.service.getmail(this.mail).subscribe((result:any) => {console.log(result)});
  }

}
