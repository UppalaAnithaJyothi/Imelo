import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
declare var jQuery: any;
@Component({
  selector: 'app-restaurant-menu',
  templateUrl: './restaurant-menu.component.html',
  styleUrls: ['./restaurant-menu.component.css']
})
export class RestaurantMenuComponent implements OnInit {
rst:any;
restaurantId:any;
foodList:any;
editObject:any;
  constructor(private service :RestaurantService) {
    this.editObject={
      restaurant:{}
    };
   }

  ngOnInit(): void {
    this.rst =  JSON.parse(localStorage.getItem('restaurant'));

    this.service.getFoodByRestaurantId(this.rst.restaurantId).subscribe((result: any) => { console.log(result); this.foodList = result; });
  }

  delete(food:any): any {
    this.service.deleteFood(food).subscribe((result: any) => {
      console.log(food);
      const i = this.foodList.findIndex((element) => {
        return element.foodId === food.foodId;
      });
      this.foodList.splice(i, 1);
    });
  }

  showEditPopup(food: any) {
    this.editObject = food;
    jQuery('#foodModel').modal('show');
  }
  updateFood() {
    this.editObject.restaurant=this.rst;
    this.service.updateFood(this.editObject).subscribe();
    console.log(this.editObject);
  }

}
