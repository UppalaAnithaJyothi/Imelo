import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'restaurant'
})
export class RestaurantPipe implements PipeTransform {

  transform(restaurants: any, searchText: any): any {
    if(searchText == null) return restaurants;

    return restaurants.filter(function(restaurant){
      //return restaurant.area.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
      if(restaurant.area.toLowerCase().indexOf(searchText.toLowerCase()) > -1){
     return true;
      }
       else if(restaurant.restaurantName.toLowerCase().indexOf(searchText.toLowerCase()) > -1){
        return true;
      }
    })

  }
  }

  