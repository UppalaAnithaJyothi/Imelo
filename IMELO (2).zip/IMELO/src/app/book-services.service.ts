import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {  } from './table-book/table-book.component';
@Injectable({
  providedIn: 'root'
})
export class BookServicesService {

  
  private tableDetails = new BehaviorSubject<any>(null);
  constructor() {

   }
}
