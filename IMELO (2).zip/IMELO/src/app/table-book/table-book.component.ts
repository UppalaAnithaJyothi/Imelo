import { Component, OnInit,Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
import * as _moment from 'moment';
import { Moment } from 'moment';
const moment = _moment;
@Component({
  selector: 'app-table-book',
  templateUrl: './table-book.component.html',
  styleUrls: ['./table-book.component.css']
})
export class TableBookComponent implements OnInit {
@Output() book:any;
restaurant:any;
tableList:any;
orderType:any;
getTable:any;
currentTime: any
minDate: any;
maxDate: Moment;
  a:any;
  b:any;

  constructor(private router:Router, private service:RestaurantService) { 
    this.book={date:'',time:'',guests:'',adds:''};
  }

  ngOnInit(): void {
    
 this.restaurant =  JSON.parse(sessionStorage.getItem('restaurant'));
 this.orderType = JSON.parse(sessionStorage.getItem('orderType'));
 this.tableList = this.restaurant.tableList

  }
  showBook(){
    console.log(this.book);
    sessionStorage.setItem('bookDetails', JSON.stringify(this.book));
    this.router.navigate(['final']);
    console.log(this.restaurant.restaurantId)
    this.service.getTableByRestaurantIdTime(this.restaurant.restaurantId, this.book.time).subscribe((result:any) => {console.log(result); this.getTable = result;
    this.getTable.availability = this.getTable.availability - 1
    console.log(this.getTable)
    this.service.updateTable(this.getTable).subscribe();


  
  });
    console.log(this.getTable)
  }
  showFood(){
    sessionStorage.setItem('bookDetails', JSON.stringify(this.book));
    this.router.navigate(['displayfood']);
   
  }
  check(table:any){
    this.currentTime = new Date().getTime()
   let date = this.book.date;
   let value = table.bookingTime;
    this.a = value.split(':');
    this.b = date.split('-')
    var x = this.b[0] + ',' + this.b[1] + ',' + this.b[2] + ' ' + this.a[0] + ':' + this.a[1];
    var finaldate = new Date(x);
    console.log("date"+finaldate)
    console.log("availability"+table.availability)
    if(finaldate > new Date() && table.availability != 0){
      return false;
    }
    else{
      return true;
    }
    
  } 

}
