import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-table-register',
  templateUrl: './table-register.component.html',
  styleUrls: ['./table-register.component.css']
})
export class TableRegisterComponent implements OnInit {
restaurant:any;
tableDetails:any;
  constructor(private service: RestaurantService) { 
    this.tableDetails={tableId :'', bookingTime:'', availability:'', 
    restaurant:{
      restaurantId:'', restaurantName:''}}

  }

  ngOnInit(): void {
    this.restaurant =  JSON.parse(localStorage.getItem('restaurant'));
  }
  tableSubmit(tableForm:any):void{
    this.tableDetails.restaurant.restaurantId = this.restaurant.restaurantId;
    this.service.registerTable(this.tableDetails).subscribe((result:any)=>{console.log(result)});
    console.log(tableForm);
    //this.router.navigate(['show-emp']);
  }

}
