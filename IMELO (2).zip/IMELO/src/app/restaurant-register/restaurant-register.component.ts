import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

declare var jQuery: any;
@Component({
  selector: 'app-restaurant-register',
  templateUrl: './restaurant-register.component.html',
  styleUrls: ['./restaurant-register.component.css']
})
export class RestaurantRegisterComponent implements OnInit {
  restaurantDetails: any;
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private service: RestaurantService, private router: Router, private toastr: ToastrService) {
    this.restaurantDetails = {restaurantId: '', restaurantName: '', category: '', estPrice: '',status:'', area: '', street:'',apt:'',landmark:'',pin:'',password: '', workingHours: '', email: '', description:''};
  }
  ngOnInit(): void {
  }
  handFileInput(file: FileList) {
    this.fileToUpload = file.item(0);

    //Show Image Preview
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }

  registerSubmit(registerForm: any) {
    console.log(this.restaurantDetails);
    console.log(jQuery('#myInput').val());
    console.log(registerForm.password);
    if (registerForm.password === jQuery('#myInput').val()) {
      /* this.restaurantDetails.restaurantName = registerForm.restaurantName;
       this.restaurantDetails.category = registerForm.category;
       this.restaurantDetails.estPrice = registerForm.estPrice;
       this.restaurantDetails.location = registerForm.location;
       this.restaurantDetails.password = registerForm.password;
       this.restaurantDetails.status = registerForm.confirmPassword;
       this.restaurantDetails.email = registerForm.email;*/
      jQuery('#msg').show();
      this.toastr.success('Thankyou for registering with us!!We will be contacting you soon...', 'Success');
      this.router.navigate(['']);
      registerForm.status="pending";
      this.service.postFiler(registerForm, this.fileToUpload).subscribe(data => {
        console.log('done');
        this.imageUrl = '/assets/image/default.png';
        
      });

     
    


    }
    else {
      alert("Password and confirm password not match.");
    }

  }



}
