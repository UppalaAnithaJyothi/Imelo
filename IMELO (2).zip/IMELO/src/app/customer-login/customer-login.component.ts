import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
import { ToastrService } from 'ngx-toastr';
import { async } from '@angular/core/testing';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;

  email:any;
  password:any;
  customer:any;
  auth2: any;
  show: boolean;
  Name: any;
  cust:any;
  test:any;
  constructor(private ngZone: NgZone,private router:Router, private service: RestaurantService,private toastr:ToastrService) {
    this.cust={customerId :'', fullName:'', email:'', password:'',  phone:''};
   } 

  async loginSubmit(loginForm:any){
    console.log(this.email);
    console.log(this.password);
   // this.service.getCustomerByEmail(this.email).subscribe((result:any) => {console.log(result); this.test = result;});
   if(this.email=="admin" && this.password == "admin"){
    this.router.navigate(['admin']);
   }
   else{ 
     await this.service.getCustomerByEmailPassword(loginForm.email, loginForm.password).
    then((result:any) => {console.log(result); this.customer = result;});
     if(this.customer != null){
        sessionStorage.setItem('customer', JSON.stringify(this.customer));
        this.router.navigate(['customerHome']); 
      }
      else if(this.test != null){
        this.toastr.error('Password Incorrect..Please try again','Error');
      }
       
      else{
        this.toastr.error('Invalid Credentials','Error');
       }
       console.log(loginForm);
      
    

  }}

 ngOnInit() {
    this.googleInitialize();
  }

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '695675220482-bt3okj1ell7bnrejgferpt7ah2bk2lv5.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
    async  (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('ID: ' + profile.getId());
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        
   await this.service.getCustomerByEmail(profile.getEmail()).then((result:any) => {console.log(result); this.test = result;
      if(this.test === null){
          alert('entered if');
          this.cust.fullName=profile.getName();
          this.cust.email=profile.getEmail();
          sessionStorage.setItem('customer', JSON.stringify(this.cust));
         this.service.registerCustomer(this.cust).subscribe();
          console.log(this.cust);
         
        
          alert('registered!!');
        }
        sessionStorage.setItem('customer', JSON.stringify(this.test));
        
        
        });
        

        
        alert('LoginSuccessfull!!');
        //this.router.navigate(['customerHome']);
        this.check();
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
  check() {
    this.ngZone.run(() =>this.router.navigate(['customerHome'])).then();
  }
  goToRegister(){
    this.router.navigate(['customerRegister']);
  }
}


