import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Subject } from 'rxjs';
import * as _ from 'underscore';
import { element } from 'protractor';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
isUserLogged:any
cartItems=[];
foodToBeAdded:Subject<any>;
amount = 0;
cartItem:any;
displayCartItems=[];


  constructor(private httpClient:HttpClient) {
    this.isUserLogged = false;
    this.cartItem={foodId:'', price:'', quantity:'', totalPrice:''};
  }
  setUserLoggedIn():void{
    this.isUserLogged = true;
  }

  setUserLoggedOut():void{
    this.isUserLogged = false;
  }
  addToCart(cartItem:any){
    var element = _.findWhere(this.cartItems,{foodId: cartItem.food.foodId});
    var element2 = _.findWhere(this.displayCartItems,{food: cartItem.food});
    if(typeof(element) == 'undefined' && element == null){
      console.log('Cart Item food : ', cartItem.food);
      this.displayCartItems.push({food:cartItem.food,quantity:cartItem.quantity,price: cartItem.price, totalPrice:cartItem.totalPrice});
      console.log('Cart Items : ', this.cartItems);
      this.cartItems.push({foodId: cartItem.food.foodId, quantity: cartItem.quantity, price: cartItem.price, totalPrice: cartItem.totalPrice});
   }else{
    element.quantity = parseInt(element.quantity)  + parseInt(cartItem.quantity);
    element.totalPrice = parseInt(element.quantity) * parseFloat(element.price);
    
    element2.quantity = parseInt(element2.quantity)  + parseInt(cartItem.quantity);
    element2.totalPrice = parseInt(element2.quantity) * parseFloat(element2.price);
  }this.calcAmount();
  }

registerRestaurant(restaurant: any) {
    return this.httpClient.post('RESTAPI2018/webapi/myresource/registerRestaurant', restaurant);
}
registerCustomer(customer: any) {
  return this.httpClient.post('RESTAPI2018/webapi/myresource/registerCustomer', customer);
}

getCustomerByEmail(email: any) {
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getCustomerByEmail/'+ email).toPromise();
}

getRestaurantByEmailPassword(email: any, password:any):any {
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getRestaurantByEmailPassword/'+ email+'/' + password).toPromise();
}
getCustomerByEmailPassword(username: any, password:any): any {
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getCustomerByEmailPassword/'+ username+'/' + password).toPromise();
}
getFoodByRestaurantId(restaurantId:any) {
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getFoodByRestaurantId/'+ restaurantId);
}
getOrdersByRestaurantId(restaurantId:any){
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getOrdersByRestaurantId/'+ restaurantId);
}
getOrdersByCustomerId(customerId:any){
  console.log("api called");
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getOrdersByCustomerId/' + customerId);
}
getTablesByRestaurantId(restaurantId:any){
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getTablesByRestaurantId/'+ restaurantId).toPromise();
}
getRestaurantByRestaurantId(restaurantId:any){
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getRestaurantById/'+ restaurantId);
}
getAllRestaurants():any{
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getAllRestaurants');
}

getAllVerifiedRestaurants():any{
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getAllVerifiedRestaurants');
}

getTableByRestaurantIdTime(restaurantId: any, bookingTime:any) {
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getTableByRestaurantIdTime/'+ restaurantId+'/' + bookingTime);
}
updateTable(getTable:any){
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateTable/', getTable);
}


postFile(ImageForm:any,fileToUpload:File, restaurant:any){
  const endpoint='RESTAPI2018/webapi/myresource/uploadImage';
  const formData:FormData = new FormData();
  formData.append('Image',fileToUpload,fileToUpload.name);
  formData.append('foodName',ImageForm.foodName);
  formData.append('category',ImageForm.category);
  formData.append('price',ImageForm.price);
  formData.append('restaurant', JSON.stringify(restaurant));
  return this.httpClient.post(endpoint,formData);
}
getmail(mail:any){
  return this.httpClient.post('RESTAPI2018/webapi/myresource/mail/',mail);

}
deleteFood(food:any){
  return this.httpClient.delete('RESTAPI2018/webapi/myresource/deleteFood/'+ food.foodId);
}
deleteTable(table:any){
  return this.httpClient.delete('RESTAPI2018/webapi/myresource/deleteTable/'+ table.tableId);
}
updateFood(getFood:any){
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateFood/', getFood);
}
registerTable(table:any){
  console.log(table);
  return this.httpClient.post('RESTAPI2018/webapi/myresource/registerTable', table);
}
postFiler(RegisterForm:any,fileToUpload:File){
  const endpoint='RESTAPI2018/webapi/myresource/uploadImagerst';
  const formData:FormData = new FormData();
  formData.append('Image',fileToUpload,fileToUpload.name);
  formData.append('restaurantName',RegisterForm.restaurantName);
  formData.append('area',RegisterForm.area);
  formData.append('email',RegisterForm.email);
  formData.append('password',RegisterForm.password);
  formData.append('category',RegisterForm.category);
  formData.append('estPrice',RegisterForm.estPrice);
  formData.append('workingHours',RegisterForm.workingHours);
  formData.append('description',RegisterForm.description);
  formData.append('status',RegisterForm.status);
  formData.append('landmark',RegisterForm.landmark);
  formData.append('street',RegisterForm.street);
  formData.append('apt',RegisterForm.apt);
  formData.append('pin',RegisterForm.pin);
  return this.httpClient.post(endpoint,formData);
}
delete(item:any){
const i = this.cartItems.findIndex((element) => { return element.foodId == item.food.foodId;});
this.cartItems.splice(i , 1);
console.log("cartItems", this.cartItems)
const j = this.displayCartItems.findIndex((element) => { return element.food.foodId == item.food.foodId;});
this.displayCartItems.splice(j , 1);
console.log("displayCartItems", this.displayCartItems)
this.calcAmount();

}
update(editObject:any){
var element = _.findWhere(this.cartItems,{foodId:editObject.food.foodId});
console.log(element);
element.quantity=editObject.quantity;
element.totalPrice = parseInt(editObject.quantity) * parseFloat(editObject.food.price);

var element2 = _.findWhere(this.displayCartItems,{food:editObject.food});
console.log(element2);
element2.quantity=editObject.quantity;
element2.totalPrice = parseInt(editObject.quantity) * parseFloat(editObject.food.price);
this.calcAmount();
console.log("cartItems in service update", this.cartItems)
console.log("cartItems in service update", this.displayCartItems)
}

confirmOrders(restaurant:any,customer:any,orderType:any,amount:any,bookDetails:any){
  // console.log("service");
  // console.log(orderType);
  // console.log(amount);
  // console.log(bookDetails);
  // console.log('Inside Service : ', this.cartItems);

  const formData:FormData = new FormData();
  formData.append('restaurantId', restaurant.restaurantId);
  formData.append('customerId', customer.customerId);
  console.log('Inside Service : ', this.cartItems);
  formData.append('items', JSON.stringify(this.cartItems));
  formData.append('orderType', orderType);
  formData.append('amount', amount);
  formData.append('bookDetails',JSON.stringify(bookDetails));
  this.displayCartItems.splice(0, this.cartItems.length);
  this.cartItems = []
  this.amount = 0
  return this.httpClient.post('RESTAPI2018/webapi/myresource/confirmOrders', formData);
}

calcAmount():any{
  this.amount=0;
  for(let i = 0; i < this.cartItems.length;i++){

    this.amount+= parseFloat(this.cartItems[i].totalPrice);
      console.log(this.cartItems[i].totalPrice)
    }
    console.log(this.amount)
}
getOrderDetailsByOrderId(orderId:any){
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getOrderDetailsByOrderId/'+ orderId);
}

deleteRestaurant(restaurant:any){
  return this.httpClient.delete('RESTAPI2018/webapi/myresource/deleteRst/'+ restaurant.restaurantId);
}
updateRestaurant(restaurant:any){
  console.log("in service",restaurant)
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateRst/', restaurant);
}
updateRest(restaurant:any){
  console.log("in service",restaurant)
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateRest/', restaurant);
}
updateRating(rate:any){
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateRating/', rate);
}
registerRating(ratingReg: any) {
  return this.httpClient.post('RESTAPI2018/webapi/myresource/registerRating', ratingReg);
  
}
getRating(restaurantId:any){
  return this.httpClient.get('RESTAPI2018/webapi/myresource/getRating/'+restaurantId);
}
updateOrder(orderUpdate:any){
  console.log("In service update order",orderUpdate)
  return this.httpClient.put('RESTAPI2018/webapi/myresource/updateOrder/', {orderId:orderUpdate.orderId,rating:orderUpdate.rating});
}
}
