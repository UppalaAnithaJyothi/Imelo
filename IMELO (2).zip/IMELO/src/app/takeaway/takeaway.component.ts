import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-takeaway',
  templateUrl: './takeaway.component.html',
  styleUrls: ['./takeaway.component.css']
})
export class TakeawayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
