import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
 declare var  jQuery:any;
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
items:any;
editObject:any;
  constructor(private service:RestaurantService) {
    this.editObject= {status: ''};
  }

  ngOnInit() {
    //alert('Welcome to Admin');
    this.service.getAllRestaurants().subscribe((result: any) => {console.log(result); this.items = result;});
   //alert('Data Recieved..'); 
  }

  delete(item:any){
    this.service.deleteRestaurant(item).subscribe((result: any) => {
      const i = this.items.findIndex((element) => {
        return element.restaurantId === item.restaurantId;
      });
      this.items.splice(i, 1);
    });
  }
  edit(item:any){
      this.editObject=item;
      jQuery('#editModel').modal('show');
  }
  update(){
    this.service.updateRestaurant(this.editObject).subscribe();
  }
}
