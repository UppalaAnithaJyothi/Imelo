import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {
restaurants:any;
orderType:any;
searchText:any
customer: any;


  constructor(private service:RestaurantService, private router:Router) {
   /* this.restaurantsp=[{id:'1', name:'Minerva', workinghours:'12pm-3pm',pricefortwo:'209'},
    {id:'2', name:'Tabla', workinghours:'12pm-3pm', pricefortwo:'209'}]*/
  }

  ngOnInit(): void {
    this.service.getAllVerifiedRestaurants().subscribe((result: any) => { console.log('Inside ', result); this.restaurants = result;});
    this.customer =  JSON.parse(sessionStorage.getItem('customer'));
  }
  reserveTable(restaurant:any){
  this.orderType = 'Table Reservation';
  sessionStorage.setItem('restaurant', JSON.stringify(restaurant))
  sessionStorage.setItem('orderType', JSON.stringify(this.orderType))
  this.router.navigate(['tableBook']);

  }
  menu(restaurant:any){
    sessionStorage.setItem('restaurant', JSON.stringify(restaurant))
    this.router.navigate(['menu']);

  }
  takeaway(restaurant:any){
    this.orderType = 'Takeaway';
    sessionStorage.setItem('restaurant', JSON.stringify(restaurant))
    sessionStorage.setItem('orderType', JSON.stringify(this.orderType))
    this.router.navigate(['displayfood']);
  }
  getRate(restaurant:any){
    var rate = 0
    this.service.getRating(restaurant.restaurantId).subscribe((result:any) => { console.log(result); rate = result;});
    return rate;
  }

}
